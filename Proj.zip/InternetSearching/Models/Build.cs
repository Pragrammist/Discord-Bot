﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OCHKO
{
    public class Build
    {
        public string SourceUrl { get; set; }//Web page where build was gotten
        public string ImgUrl { get; set; } //img url of build
        public string Note { get; set; } //take from article 
        public string ShortDescription { get; set; } //take from article 

    }
}
